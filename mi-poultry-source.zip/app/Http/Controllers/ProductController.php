<?php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Services\Contracts\SeoServiceInterface;

class ProductController extends Controller
{
    public function index(SeoServiceInterface $seo)
    {
        $seo->setTitle(__('messages.products_title'));

        return view('products.index', [
            'products' => Product::active()->get(),
            'seo'      => $seo->toArray(),
        ]);
    }

    public function show(Product $product, SeoServiceInterface $seo)
    {
        $seo->setTitle($product->seoTitle())
            ->setDescription($product->seoDescription())
            ->setImage($product->getMainImageUrl('large'))
            ->setType('product');

        return view('products.show', [
            'product' => $product,
            'related' => Product::active()->where('id', '!=', $product->id)->take(3)->get(),
            'seo'     => $seo->toArray(),
        ]);
    }
}
