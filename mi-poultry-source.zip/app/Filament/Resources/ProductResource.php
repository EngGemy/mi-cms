<?php

namespace App\Filament\Resources;

use App\Filament\Resources\ProductResource\Pages;
use App\Models\Product;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;
use Filament\Forms\Components\SpatieMediaLibraryFileUpload;

class ProductResource extends Resource
{
    protected static ?string $model = Product::class;
    protected static ?string $navigationIcon = 'heroicon-o-cube';
    protected static ?string $navigationGroup = 'الكتالوج';
    protected static ?int $navigationSort = 1;
    protected static ?string $label = 'منتج';
    protected static ?string $pluralLabel = 'المنتجات';

    public static function form(Form $form): Form
    {
        return $form->schema([
            Forms\Components\Tabs::make()->tabs([
                Forms\Components\Tabs\Tab::make('المحتوى')->schema([
                    Forms\Components\TextInput::make('name')->label('الاسم')->required()->maxLength(255),
                    Forms\Components\Textarea::make('summary')->label('الملخص')->rows(2),
                    Forms\Components\Textarea::make('description')->label('الوصف الكامل')->rows(6),
                    Forms\Components\TextInput::make('badge')->label('شارة (Badge)')->maxLength(60),
                    Forms\Components\KeyValue::make('specs')
                        ->label('المواصفات (مفتاح/قيمة)')
                        ->keyLabel('المواصفة')
                        ->valueLabel('القيمة'),
                ]),
                Forms\Components\Tabs\Tab::make('الوسائط')->schema([
                    SpatieMediaLibraryFileUpload::make('main')
                        ->label('الصورة الرئيسية')
                        ->collection('main')->image()->imageEditor(),
                    SpatieMediaLibraryFileUpload::make('gallery')
                        ->label('معرض الصور')
                        ->collection('gallery')->multiple()->reorderable()->image(),
                ]),
                Forms\Components\Tabs\Tab::make('SEO')->schema([
                    Forms\Components\TextInput::make('seo_title')->label('عنوان SEO')->maxLength(120),
                    Forms\Components\Textarea::make('seo_description')->label('وصف SEO')->rows(3)->maxLength(170),
                ]),
                Forms\Components\Tabs\Tab::make('الإعدادات')->schema([
                    Forms\Components\TextInput::make('position')->numeric()->default(0),
                    Forms\Components\Toggle::make('is_active')->default(true),
                    Forms\Components\Toggle::make('is_featured'),
                ]),
            ])->columnSpanFull(),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\SpatieMediaLibraryImageColumn::make('main')->collection('main')->square(),
                Tables\Columns\TextColumn::make('name')->searchable(),
                Tables\Columns\TextColumn::make('badge'),
                Tables\Columns\TextColumn::make('position')->sortable(),
                Tables\Columns\IconColumn::make('is_featured')->boolean(),
                Tables\Columns\IconColumn::make('is_active')->boolean(),
            ])
            ->defaultSort('position')
            ->reorderable('position')
            ->filters([
                Tables\Filters\TernaryFilter::make('is_active'),
                Tables\Filters\TernaryFilter::make('is_featured'),
            ]);
    }

    public static function getPages(): array
    {
        return [
            'index'  => Pages\ListProducts::route('/'),
            'create' => Pages\CreateProduct::route('/create'),
            'edit'   => Pages\EditProduct::route('/{record}/edit'),
        ];
    }
}
