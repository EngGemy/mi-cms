<?php
namespace App\Filament\Resources\NewsletterSubscriberResource\Pages;
use App\Filament\Resources\NewsletterSubscriberResource;
use Filament\Resources\Pages\EditRecord;
class EditNewsletterSubscriber extends EditRecord { protected static string $resource = NewsletterSubscriberResource::class; }
