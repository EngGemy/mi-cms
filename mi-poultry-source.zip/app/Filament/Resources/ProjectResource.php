<?php

namespace App\Filament\Resources;

use App\Filament\Resources\ProjectResource\Pages;
use App\Models\Project;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;
use Filament\Forms\Components\SpatieMediaLibraryFileUpload;

class ProjectResource extends Resource
{
    protected static ?string $model = Project::class;
    protected static ?string $navigationIcon = 'heroicon-o-photo';
    protected static ?string $navigationGroup = 'المشاريع والمعرض';
    protected static ?int $navigationSort = 1;
    protected static ?string $label = 'مشروع';
    protected static ?string $pluralLabel = 'المشاريع';

    public static function form(Form $form): Form
    {
        return $form->schema([
            Forms\Components\TextInput::make('title')->label('العنوان')->required(),
            Forms\Components\TextInput::make('client_name')->label('العميل'),
            Forms\Components\Select::make('category')->options([
                'layer'=>'إنتاج البيض','broiler'=>'التسمين',
                'commercial'=>'تجاري','machinery'=>'آلات ومعدّات'
            ])->required(),
            Forms\Components\TextInput::make('location_code')->label('وصف الموقع/السعة')
                ->placeholder('DAMIETTA · 480K BIRDS · 2025'),
            Forms\Components\TextInput::make('capacity_birds')->numeric()->label('سعة الطيور'),
            Forms\Components\TextInput::make('year')->numeric()->label('السنة')->maxLength(4),
            Forms\Components\Textarea::make('description')->rows(4),
            SpatieMediaLibraryFileUpload::make('cover')->collection('cover')->image()->imageEditor(),
            SpatieMediaLibraryFileUpload::make('gallery')->collection('gallery')->multiple()->reorderable()->image(),
            Forms\Components\TextInput::make('position')->numeric()->default(0),
            Forms\Components\Toggle::make('is_featured'),
            Forms\Components\Toggle::make('is_active')->default(true),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\SpatieMediaLibraryImageColumn::make('cover')->collection('cover')->square(),
                Tables\Columns\TextColumn::make('title')->searchable(),
                Tables\Columns\TextColumn::make('category')->badge(),
                Tables\Columns\TextColumn::make('year'),
                Tables\Columns\IconColumn::make('is_featured')->boolean(),
                Tables\Columns\IconColumn::make('is_active')->boolean(),
            ])->filters([
                Tables\Filters\SelectFilter::make('category')->options(Project::CATEGORIES + ['layer'=>'Layer']),
            ])->defaultSort('position')->reorderable('position');
    }

    public static function getPages(): array
    {
        return [
            'index'  => Pages\ListProjects::route('/'),
            'create' => Pages\CreateProject::route('/create'),
            'edit'   => Pages\EditProject::route('/{record}/edit'),
        ];
    }
}
