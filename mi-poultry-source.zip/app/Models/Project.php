<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\MediaLibrary\HasMedia;
use Spatie\MediaLibrary\InteractsWithMedia;
use Spatie\MediaLibrary\MediaCollections\Models\Media;
use Spatie\Translatable\HasTranslations;

class Project extends Model implements HasMedia
{
    use HasFactory, HasTranslations, InteractsWithMedia;

    public array $translatable = ['title', 'client_name', 'description'];

    protected $fillable = [
        'title', 'client_name', 'description',
        'category', 'location_code', 'capacity_birds', 'year',
        'position', 'is_featured', 'is_active',
    ];

    protected $casts = [
        'is_active'      => 'boolean',
        'is_featured'    => 'boolean',
        'capacity_birds' => 'integer',
        'year'           => 'integer',
        'position'       => 'integer',
    ];

    public const CATEGORIES = [
        'layer'      => ['ar' => 'إنتاج البيض', 'en' => 'Layer'],
        'broiler'    => ['ar' => 'التسمين',     'en' => 'Broiler'],
        'commercial' => ['ar' => 'تجاري كبير',  'en' => 'Commercial'],
        'machinery'  => ['ar' => 'آلات ومعدّات','en' => 'Machinery'],
    ];

    public function registerMediaCollections(): void
    {
        $this->addMediaCollection('cover')->singleFile();
        $this->addMediaCollection('gallery');   // multiple project photos
    }

    public function registerMediaConversions(?Media $media = null): void
    {
        $this->addMediaConversion('hero')->width(1600)->quality(85);
        $this->addMediaConversion('card')->width(900)->quality(82);
        $this->addMediaConversion('thumb')->width(400)->quality(80);
    }

    public function getCoverUrl(string $conv = 'card'): ?string
    {
        $m = $this->getFirstMedia('cover');
        return $m ? $m->getUrl($conv) : null;
    }

    public function getCategoryLabel(): string
    {
        $locale = app()->getLocale();
        return self::CATEGORIES[$this->category][$locale] ?? $this->category;
    }

    public function scopeActive($q) { return $q->where('is_active', true)->orderBy('position'); }
    public function scopeOfCategory($q, string $c) { return $q->where('category', $c); }
}
