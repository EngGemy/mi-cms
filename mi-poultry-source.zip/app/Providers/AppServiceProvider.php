<?php

namespace App\Providers;

use App\Services\CalculatorService;
use App\Services\Contracts\CalculatorServiceInterface;
use App\Services\Contracts\SeoServiceInterface;
use App\Services\SeoService;
use Illuminate\Pagination\Paginator;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        // SOLID Dependency Inversion: bind interfaces to concrete implementations
        $this->app->bind(CalculatorServiceInterface::class, function () {
            return new CalculatorService(config('mi.calculator'));
        });

        $this->app->singleton(SeoServiceInterface::class, SeoService::class);
    }

    public function boot(): void
    {
        Paginator::useTailwind();
    }
}
