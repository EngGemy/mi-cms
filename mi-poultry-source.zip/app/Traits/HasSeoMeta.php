<?php

namespace App\Traits;

/**
 * Adds SEO meta helpers to translatable models that have
 * `seo_title` and `seo_description` translatable JSON columns.
 */
trait HasSeoMeta
{
    public function seoTitle(?string $fallback = null): string
    {
        return $this->getTranslation('seo_title', app()->getLocale(), false)
            ?: $this->getTranslation('title', app()->getLocale(), false)
            ?: $this->getTranslation('name', app()->getLocale(), false)
            ?: ($fallback ?? config('app.name'));
    }

    public function seoDescription(?string $fallback = null): string
    {
        return $this->getTranslation('seo_description', app()->getLocale(), false)
            ?: $this->getTranslation('summary', app()->getLocale(), false)
            ?: $this->getTranslation('excerpt', app()->getLocale(), false)
            ?: ($fallback ?? '');
    }
}
