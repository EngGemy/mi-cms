<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\BlogController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\ContactController;
use App\Http\Controllers\NewsletterController;
use App\Http\Controllers\SitemapController;
use App\Http\Controllers\LocaleController;

/*
|--------------------------------------------------------------------------
| Public Web Routes — bilingual via {locale} prefix
|--------------------------------------------------------------------------
| The SetLocale middleware enforces ar|en and falls back to APP_LOCALE.
*/

// Locale switcher endpoint (writes a cookie, redirects back)
Route::get('lang/{locale}', [LocaleController::class, 'switch'])
    ->whereIn('locale', ['ar', 'en'])
    ->name('locale.switch');

// SEO
Route::get('sitemap.xml', SitemapController::class)->name('sitemap');
Route::view('robots.txt', 'robots')->name('robots');

Route::group([
    'prefix' => '{locale}',
    'where'  => ['locale' => 'ar|en'],
    'middleware' => ['web', 'set.locale'],
], function () {

    Route::get('/', [HomeController::class, '__invoke'])->name('home');

    // Products
    Route::get('products', [ProductController::class, 'index'])->name('products.index');
    Route::get('products/{product:slug}', [ProductController::class, 'show'])->name('products.show');

    // Blog
    Route::get('blog', [BlogController::class, 'index'])->name('blog.index');
    Route::get('blog/category/{category:slug}', [BlogController::class, 'category'])->name('blog.category');
    Route::get('blog/{post:slug}', [BlogController::class, 'show'])->name('blog.show');
    Route::post('blog/{post:slug}/comment', [BlogController::class, 'comment'])->name('blog.comment');

    // Contact form
    Route::post('contact', [ContactController::class, 'store'])->name('contact.store');

    // Newsletter
    Route::post('newsletter', [NewsletterController::class, 'store'])->name('newsletter.store');
});

// Default redirect to APP_LOCALE
Route::get('/', function () {
    return redirect(app()->getLocale());
});
