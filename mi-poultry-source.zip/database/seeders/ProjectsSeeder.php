<?php

namespace Database\Seeders;

use App\Models\Project;
use Illuminate\Database\Seeder;
use Illuminate\Support\Str;

class ProjectsSeeder extends Seeder
{
    public function run(): void
    {
        $projects = [
            ['ar_t'=>'مزرعة الصحراء — 4 عنابر بياض','en_t'=>'Sahara Farm — 4 layer houses','meta'=>'RIYADH · 240K BIRDS · 2024','cat'=>'layer','img'=>'https://plus.unsplash.com/premium_photo-1661930553507-59420df08d82?w=1400&q=85&auto=format&fit=crop'],
            ['ar_t'=>'مزارع الكبير — H-Frame 4 طوابق','en_t'=>'Kabir Farms — H-Frame 4 tiers','meta'=>'SHARQIA · 120K BIRDS · 2025','cat'=>'broiler','img'=>'https://images.unsplash.com/photo-1553531009-c4605f302b47?w=1200&q=85&auto=format&fit=crop'],
            ['ar_t'=>'دواجن النيل — 6 عنابر متكاملة','en_t'=>'Nile Poultry — 6 integrated houses','meta'=>'DAMIETTA · 480K BIRDS · 2025','cat'=>'commercial','img'=>'https://images.unsplash.com/photo-1569466593977-94ee7ed02ec9?w=1200&q=85&auto=format&fit=crop'],
            ['ar_t'=>'بطاريات مغلفنة A-Type','en_t'=>'Galvanized A-Type Cages','meta'=>'FACTORY · 2026 BATCH','cat'=>'machinery','img'=>'https://images.unsplash.com/photo-1582661629051-43eadd614098?w=1200&q=85&auto=format&fit=crop'],
            ['ar_t'=>'منظومة جمع بيض أوتوماتيكية','en_t'=>'Automatic Egg Collection System','meta'=>'MENOUFIA · 12.4K EGGS/DAY','cat'=>'layer','img'=>'https://images.unsplash.com/photo-1648141499246-97a0eb56c2fd?w=1200&q=85&auto=format&fit=crop'],
            ['ar_t'=>'القاهرة للدواجن — تسمين كثيف','en_t'=>'Cairo Poultry — Intensive Broilers','meta'=>'CAIRO · 180K BIRDS · 2024','cat'=>'broiler','img'=>'https://images.unsplash.com/photo-1531155179084-3e1f15110922?w=1200&q=85&auto=format&fit=crop'],
            ['ar_t'=>'الوطنية — مجمّع 8 عنابر','en_t'=>'Al-Watanya — 8-House Complex','meta'=>'SAUDI ARABIA · 640K BIRDS · 2024','cat'=>'commercial','img'=>'https://plus.unsplash.com/premium_photo-1682126534413-5c7ac3ac54c4?w=1400&q=85&auto=format&fit=crop'],
            ['ar_t'=>'أنظمة تهوية أنفاق + Cooling Pad','en_t'=>'Tunnel Ventilation + Cooling Pads','meta'=>'FACTORY · V-PRO SERIES','cat'=>'machinery','img'=>'https://images.unsplash.com/photo-1441122456239-401e92b73c65?w=1400&q=85&auto=format&fit=crop'],
        ];

        foreach ($projects as $i => $p) {
            Project::updateOrCreate(
                ['slug' => Str::slug($p['en_t'])],
                [
                    'title' => ['ar' => $p['ar_t'], 'en' => $p['en_t']],
                    'meta' => $p['meta'],
                    'category' => $p['cat'],
                    'image_url' => $p['img'],
                    'order' => $i + 1,
                    'is_active' => true,
                ]
            );
        }
    }
}
