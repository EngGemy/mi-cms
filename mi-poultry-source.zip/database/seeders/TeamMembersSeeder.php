<?php

namespace Database\Seeders;

use App\Models\TeamMember;
use Illuminate\Database\Seeder;

class TeamMembersSeeder extends Seeder
{
    public function run(): void
    {
        $team = [
            [
                'role_key' => 'sales',
                'name' => ['ar' => 'م. كريم العش', 'en' => 'Eng. Karim El-Esh'],
                'role' => ['ar' => 'مدير المبيعات', 'en' => 'Sales Manager'],
                'description' => ['ar' => 'عروض أسعار رسمية مفصّلة، دراسات جدوى، وتخطيط مشاريع جديدة. خبرة 12+ سنة.',
                                  'en' => 'Detailed quotes, feasibility studies, project planning. 12+ years experience.'],
                'phone' => '+201030003186',
                'whatsapp' => '201030003186',
                'avatar_initials' => 'ك.ع',
                'is_featured' => true,
            ],
            [
                'role_key' => 'support',
                'name' => ['ar' => 'قسم الدعم الفني', 'en' => 'Technical Support'],
                'role' => ['ar' => 'الدعم الفني · 24/7', 'en' => 'Field Technical Support · 24/7'],
                'description' => ['ar' => 'استجابة خلال 4 ساعات لمحافظات الدلتا. قطع غيار محلية + فريق هندسي.',
                                  'en' => '4-hour response in Delta governorates. Local spare parts + engineering team.'],
                'phone' => '+201030003186',
                'whatsapp' => '201030003186',
                'avatar_initials' => 'د.ف',
                'is_featured' => false,
            ],
            [
                'role_key' => 'customer-service',
                'name' => ['ar' => 'قسم خدمة العملاء', 'en' => 'Customer Service'],
                'role' => ['ar' => 'متابعة العملاء والصيانة', 'en' => 'Customer & Maintenance'],
                'description' => ['ar' => 'متابعة ما بعد البيع، جدولة الصيانة الدورية، الاستفسارات.',
                                  'en' => 'After-sales follow-up, scheduled maintenance, inquiries.'],
                'phone' => '+201030003186',
                'whatsapp' => '201030003186',
                'avatar_initials' => 'خ.ع',
                'is_featured' => false,
            ],
        ];

        foreach ($team as $i => $m) {
            TeamMember::updateOrCreate(['role_key' => $m['role_key']], array_merge($m, ['order' => $i + 1, 'is_active' => true]));
        }
    }
}
