<?php

namespace Database\Seeders;

use App\Models\Product;
use Illuminate\Database\Seeder;
use Illuminate\Support\Str;

class ProductsSeeder extends Seeder
{
    public function run(): void
    {
        $items = [
            [
                'name' => ['ar' => 'بطاريات التسمين H-Frame', 'en' => 'H-Frame Broiler Cages'],
                'badge' => ['ar' => 'الأكثر طلباً', 'en' => 'Best Seller'],
                'description' => ['ar' => 'نظام H-Frame متعدد الطوابق للتسمين الصناعي. أعلى معدلات نمو في أقل وقت، سيور آلية للسماد والطيور.',
                                  'en' => 'Multi-tier H-Frame system for industrial broilers. Highest growth rates with automated manure/bird conveyors.'],
                'specs' => ['ar' => ['السعة' => '96 طائر/وحدة', 'الطوابق' => '3-5'], 'en' => ['Capacity' => '96 birds/unit', 'Tiers' => '3-5']],
                'image_url' => 'https://images.unsplash.com/photo-1553531009-c4605f302b47?w=1200&q=85&auto=format&fit=crop',
            ],
            [
                'name' => ['ar' => 'بطاريات البياض A-Type', 'en' => 'A-Type Layer Cages'],
                'badge' => ['ar' => 'سيريز A', 'en' => 'A-Series'],
                'description' => ['ar' => 'بطاريات بياض ثلاثية الطوابق بجمع بيض أوتوماتيكي عبر ناقل دائم. مغلفنة بالكامل ومقاومة للصدأ.',
                                  'en' => 'Three-tier layer cages with continuous automatic egg conveyor. Fully galvanized, rust-resistant.'],
                'specs' => ['ar' => ['البيض' => '12.4K يومي', 'البقاء' => '98.2%'], 'en' => ['Eggs' => '12.4K/day', 'Survival' => '98.2%']],
                'image_url' => 'https://images.unsplash.com/photo-1630090374791-c9eb7bab3935?w=1200&q=85&auto=format&fit=crop',
            ],
            [
                'name' => ['ar' => 'أنظمة تغذية أوتوماتيكية', 'en' => 'Automatic Feeding Systems'],
                'badge' => ['ar' => 'صناعي', 'en' => 'Industrial'],
                'description' => ['ar' => 'توزيع علف دقيق بالغرام عبر سيلو متّصل، جدولة وجبات متعددة، توفير 18% في استهلاك العلف.',
                                  'en' => 'Gram-precise feed distribution via connected silo, multi-meal scheduling, 18% feed savings.'],
                'specs' => ['ar' => ['التوفير' => '18%', 'الدقّة' => '±5g'], 'en' => ['Savings' => '18%', 'Accuracy' => '±5g']],
                'image_url' => 'https://images.unsplash.com/photo-1517419800355-7ea1a4b1f68d?w=1200&q=85&auto=format&fit=crop',
            ],
            [
                'name' => ['ar' => 'تهوية أنفاق + Cooling Pad', 'en' => 'Tunnel Ventilation + Cooling Pad'],
                'badge' => ['ar' => 'تهوية', 'en' => 'Ventilation'],
                'description' => ['ar' => 'مراوح تهوية أنفاق متغيرة السرعة (VFD) ولوحات تبريد أوروبية. سرعة هواء حتى 3.5 م/ث.',
                                  'en' => 'VFD tunnel fans + European cooling pads. Airspeed up to 3.5 m/s.'],
                'specs' => ['ar' => ['السرعة' => '3.5 m/s', 'التبريد' => '-8°C'], 'en' => ['Speed' => '3.5 m/s', 'Cooling' => '-8°C']],
                'image_url' => 'https://images.unsplash.com/photo-1582661629051-43eadd614098?w=1200&q=85&auto=format&fit=crop',
            ],
            [
                'name' => ['ar' => 'منصة MI-OS للتحكم', 'en' => 'MI-OS Control Platform'],
                'badge' => ['ar' => 'منصة ذكية', 'en' => 'Smart Platform'],
                'description' => ['ar' => 'لوحة تحكم ذكية بـIoT لرؤية لحظية لكل قطيع، تنبيهات، وتقارير أداء. تكامل مباشر مع أجهزة الاستشعار.',
                                  'en' => 'IoT-based control dashboard, live flock visibility, alerts, performance reports.'],
                'specs' => ['ar' => ['الاستجابة' => '24/7', 'الحساسات' => '32+'], 'en' => ['Uptime' => '24/7', 'Sensors' => '32+']],
                'image_url' => 'https://images.unsplash.com/photo-1648141499246-97a0eb56c2fd?w=1200&q=85&auto=format&fit=crop',
            ],
            [
                'name' => ['ar' => 'صوامع الأعلاف والمخازن', 'en' => 'Feed Silos & Storage'],
                'badge' => ['ar' => 'تخزين', 'en' => 'Storage'],
                'description' => ['ar' => 'صوامع علف بسعات مختلفة، أنظمة تفريغ آلية، أبراج توزيع، وحاويات بيض ومخازن نهائية.',
                                  'en' => 'Feed silos of various capacities, automatic discharge systems, distribution towers, egg containers.'],
                'specs' => ['ar' => ['السعة' => '5-50 طن', 'المواد' => 'مغلفن'], 'en' => ['Capacity' => '5-50 t', 'Material' => 'Galvanized']],
                'image_url' => 'https://images.unsplash.com/photo-1441122456239-401e92b73c65?w=1200&q=85&auto=format&fit=crop',
            ],
        ];

        foreach ($items as $i => $p) {
            Product::updateOrCreate(
                ['slug' => Str::slug($p['name']['en'])],
                array_merge($p, ['order' => $i + 1, 'is_active' => true])
            );
        }
    }
}
