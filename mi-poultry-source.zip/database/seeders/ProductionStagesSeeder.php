<?php

namespace Database\Seeders;

use App\Models\ProductionStage;
use Illuminate\Database\Seeder;

class ProductionStagesSeeder extends Seeder
{
    public function run(): void
    {
        $stages = [
            ['ar_t' => 'التصميم الهندسي والمحاكاة', 'en_t' => 'Engineering Design & Simulation',
             'ar_d' => 'مخططات CAD ثلاثية الأبعاد، محاكاة تدفق الهواء والحرارة قبل البدء في التصنيع.',
             'en_d' => '3D CAD plans, airflow & thermal simulation before manufacturing.',
             'img' => 'https://plus.unsplash.com/premium_photo-1661930553507-59420df08d82?w=1200&q=85&auto=format&fit=crop'],
            ['ar_t' => 'قطع وتشكيل الصاج المغلفن', 'en_t' => 'Galvanized Sheet Cutting',
             'ar_d' => 'ماكينات CNC تقطع الصاج بدقة ±0.5mm. صاج مجلفن 275g/m² مقاوم للصدأ.',
             'en_d' => 'CNC cutting with ±0.5mm precision. 275g/m² galvanized rust-proof steel.',
             'img' => 'https://images.unsplash.com/photo-1504917595217-d4dc5ebe6122?w=1200&q=85&auto=format&fit=crop'],
            ['ar_t' => 'اللحام الآلي عالي الدقة', 'en_t' => 'High-Precision Robotic Welding',
             'ar_d' => 'لحام MIG/MAG بآلات ألمانية. فحص بصري على كل وصلة قبل المرحلة التالية.',
             'en_d' => 'German MIG/MAG welding. Visual inspection on every joint.',
             'img' => 'https://images.unsplash.com/photo-1565008447742-97f6f38c985c?w=1200&q=85&auto=format&fit=crop'],
            ['ar_t' => 'الجلفنة ومعالجة السطح', 'en_t' => 'Galvanization & Surface Treatment',
             'ar_d' => 'جلفنة بالغمس الساخن. عمر افتراضي 15+ سنة.',
             'en_d' => 'Hot-dip galvanization. 15+ year expected lifespan.',
             'img' => 'https://images.unsplash.com/photo-1581092335397-9583eb92d232?w=1200&q=85&auto=format&fit=crop'],
            ['ar_t' => 'فحص الجودة والاختبار', 'en_t' => 'Quality Inspection & Testing',
             'ar_d' => '3 مراحل فحص: مقاسات، تحمّل، وظيفي. كل بطارية تختبر تحت حمل أعلى من الواقعي.',
             'en_d' => 'Three-stage QA: dimensional, load, functional. Above-capacity testing.',
             'img' => 'https://images.unsplash.com/photo-1648141499246-97a0eb56c2fd?w=1200&q=85&auto=format&fit=crop'],
            ['ar_t' => 'التركيب الميداني والتشغيل', 'en_t' => 'Field Installation & Commissioning',
             'ar_d' => 'فريقنا الهندسي يُركّب في موقعك، يختبر كل نظام، يدرّب فريقك.',
             'en_d' => 'Our field team installs, tests every system, trains your staff.',
             'img' => 'https://plus.unsplash.com/premium_photo-1682126534413-5c7ac3ac54c4?w=1200&q=85&auto=format&fit=crop'],
        ];

        foreach ($stages as $i => $s) {
            ProductionStage::updateOrCreate(['order' => $i + 1], [
                'title' => ['ar' => $s['ar_t'], 'en' => $s['en_t']],
                'description' => ['ar' => $s['ar_d'], 'en' => $s['en_d']],
                'image_url' => $s['img'],
                'is_active' => true,
            ]);
        }
    }
}
