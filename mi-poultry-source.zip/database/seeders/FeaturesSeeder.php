<?php

namespace Database\Seeders;

use App\Models\Feature;
use Illuminate\Database\Seeder;

class FeaturesSeeder extends Seeder
{
    public function run(): void
    {
        $items = [
            [
                'title' => ['ar' => 'تحكم آلي بالعنبر كاملاً', 'en' => 'Full Automatic House Control'],
                'description' => ['ar' => 'تغذية، تهوية، إضاءة، تبريد، جمع بيض — كل شيء يعمل وفق جدول مبرمج.',
                                  'en' => 'Feeding, ventilation, lighting, cooling, egg collection — all programmed.'],
                'image_url' => 'https://images.unsplash.com/photo-1531155179084-3e1f15110922?w=1200&q=85&auto=format&fit=crop',
            ],
            [
                'title' => ['ar' => 'رؤية لحظية لكل قطيع', 'en' => 'Live Flock Visibility'],
                'description' => ['ar' => 'منصة MI-OS تعرض درجة الحرارة، استهلاك العلف، أداء القطيع، والتنبيهات على شاشة واحدة.',
                                  'en' => 'MI-OS shows temperature, feed consumption, flock performance, alerts — all in one screen.'],
                'image_url' => 'https://plus.unsplash.com/premium_photo-1682126534413-5c7ac3ac54c4?w=1200&q=85&auto=format&fit=crop',
            ],
            [
                'title' => ['ar' => 'ضمان شامل ومتابعة', 'en' => 'Full Warranty & Support'],
                'description' => ['ar' => 'ضمان 5 سنوات شامل، مخزون قطع غيار محلي في دمياط، وفريق هندسي ميداني جاهز.',
                                  'en' => '5-year full warranty, local spare parts stock in Damietta, field engineering team on call.'],
                'image_url' => 'https://images.unsplash.com/photo-1548550023-2bdb3c5beed7?w=1200&q=85&auto=format&fit=crop',
            ],
        ];

        foreach ($items as $i => $f) {
            Feature::updateOrCreate(['order' => $i + 1], array_merge($f, ['is_active' => true]));
        }
    }
}
