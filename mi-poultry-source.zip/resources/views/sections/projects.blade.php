<section class="py-24 lg:py-32">
  <div class="section-inner">
    <div class="grid lg:grid-cols-2 gap-10 items-end mb-10">
      <div data-reveal>
        <span class="eyebrow">{{ __('messages.projects_eyebrow') }}</span>
        <h2 class="display-2 mt-2">{{ __('messages.projects_title') }}</h2>
      </div>
      <p class="lead" data-reveal>{{ __('messages.projects_blurb') }}</p>
    </div>

    <div class="filters-row" data-reveal id="projectFilters">
      <button class="filter-pill is-active" data-filter="all">{{ __('messages.filter_all') }}</button>
      @foreach(\App\Models\Project::CATEGORIES as $key => $names)
        <button class="filter-pill" data-filter="{{ $key }}">{{ $names[app()->getLocale()] }}</button>
      @endforeach
    </div>

    <div class="projects-grid" id="projectsGrid" data-reveal>
      @foreach($projects as $i => $project)
        <div class="project-tile pt-{{ $i + 1 }}" data-cat="{{ $project->category }}">
          <span class="project-tile-cat">{{ $project->getCategoryLabel() }}</span>
          <img src="{{ $project->getCoverUrl('card') ?? 'https://images.unsplash.com/photo-1569466593977-94ee7ed02ec9?w=900&q=85&auto=format&fit=crop' }}"
               alt="{{ $project->title }}" loading="lazy"/>
          <div class="project-tile-info">
            <div class="project-tile-title">{{ $project->title }}</div>
            <div class="project-tile-meta">{{ $project->location_code }}</div>
          </div>
        </div>
      @endforeach
    </div>
  </div>
</section>
