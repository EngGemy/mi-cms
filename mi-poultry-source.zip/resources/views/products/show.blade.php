<x-layouts.public>
<article class="py-24 lg:py-32">
  <div class="section-inner">
    <div class="grid lg:grid-cols-2 gap-12 items-start">
      <div>
        <div style="border-radius:32px;overflow:hidden;aspect-ratio:4/3">
          <img src="{{ $product->getMainImageUrl('large') }}" alt="{{ $product->name }}"
               style="width:100%;height:100%;object-fit:cover"/>
        </div>
        @if($product->getMedia('gallery')->count())
          <div class="grid grid-cols-4 gap-3 mt-4">
            @foreach($product->getMedia('gallery') as $img)
              <img src="{{ $img->getUrl('thumb') }}" alt="" class="rounded-xl" style="aspect-ratio:1;object-fit:cover"/>
            @endforeach
          </div>
        @endif
      </div>
      <div>
        @if($product->badge)<span class="eyebrow">{{ $product->badge }}</span>@endif
        <h1 class="display-2 mt-2">{{ $product->name }}</h1>
        <p class="lead mt-6">{{ $product->summary }}</p>
        <div class="prose mt-8" style="line-height:1.85">{!! $product->description !!}</div>

        @if(!empty($product->specs))
          <div class="mt-8 bg-paper rounded-2xl p-6">
            <h3 class="display-3 mb-4">{{ __('messages.specs') }}</h3>
            <dl class="space-y-3">
              @foreach((array) $product->specs as $key => $val)
                <div class="flex justify-between py-2 border-b" style="border-color:rgba(26,22,17,.08)">
                  <dt style="color:var(--ink-600)">{{ $key }}</dt>
                  <dd style="font-weight:700">{{ $val }}</dd>
                </div>
              @endforeach
            </dl>
          </div>
        @endif

        <a href="/{{ app()->getLocale() }}#contact" class="btn btn-primary btn-lg mt-8" data-magnetic>
          {{ __('messages.request_quote') }} <i data-lucide="arrow-left" class="w-4 h-4"></i>
        </a>
      </div>
    </div>
  </div>
</article>
</x-layouts.public>
