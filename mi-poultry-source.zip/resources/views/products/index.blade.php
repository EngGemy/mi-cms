<x-layouts.public>
<section class="py-24 lg:py-32">
  <div class="section-inner">
    <div class="mb-12">
      <span class="eyebrow">{{ __('messages.products_eyebrow') }}</span>
      <h1 class="display-2 mt-2">{{ __('messages.products_title') }}</h1>
    </div>
    <div class="products-grid">
      @foreach($products as $product)
        <a href="{{ route('products.show', [app()->getLocale(), $product->slug]) }}" class="product-card">
          <div class="product-card-image">
            @if($product->badge)<span class="product-card-badge">{{ $product->badge }}</span>@endif
            <img src="{{ $product->getMainImageUrl('card') }}" alt="{{ $product->name }}" loading="lazy"/>
          </div>
          <div class="product-card-body">
            <h3 class="product-card-title">{{ $product->name }}</h3>
            <p class="product-card-desc">{{ $product->summary }}</p>
          </div>
        </a>
      @endforeach
    </div>
  </div>
</section>
</x-layouts.public>
