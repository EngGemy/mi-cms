<?php

return [
    'home_seo_title'         => 'Automatic Poultry Cages',
    'home_seo_description'   => 'Integrated factory for automatic poultry battery cages in Damietta — turnkey solutions for commercial farms, layers, broilers, and new investors.',
    'default_seo_description'=> 'MI · Automatic poultry cages manufacturer in Damietta, Egypt.',

    'blog_index_title'       => 'Blog',
    'blog_index_description' => 'Insights and news from the poultry industry in Egypt and the region.',

    'products_title'         => 'Products & Solutions',

    'comment_submitted' => 'Your comment has been received and will appear after moderation.',
    'contact_ok'        => 'Thank you. Our team will contact you within 24 hours.',
    'newsletter_ok'     => 'You have been subscribed to our newsletter.',
    'calc_saved'        => 'Estimate saved. Sales will reach out shortly.',
];
