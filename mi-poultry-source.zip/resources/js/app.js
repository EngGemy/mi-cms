// MI Poultry — public frontend bootstrap
import Lenis from 'lenis';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { createIcons, icons } from 'lucide';
import './app.css';

gsap.registerPlugin(ScrollTrigger);
window.Lenis = Lenis;
window.gsap = gsap;
window.ScrollTrigger = ScrollTrigger;

// Initialize Lucide icons
document.addEventListener('DOMContentLoaded', () => {
  createIcons({ icons });
  initLoader();
  initLenis();
  initRotator();
  initReveals();
  initCounters();
  initMagnetic();
  initFaq();
  initMobileMenu();
  initStagesSlider();
  initProjectsFilter();
  initSmoothAnchors();
});

let lenis;

function initLoader() {
  const el = document.getElementById('loader');
  if (!el) return;
  const pct = document.getElementById('loaderPct');
  const startTime = performance.now();
  const MIN_DURATION = 2200;

  function tick() {
    const elapsed = performance.now() - startTime;
    const t = Math.min(1, elapsed / MIN_DURATION);
    if (pct) pct.textContent = Math.round(Math.pow(t, 0.7) * 100) + '%';
    if (t < 1) requestAnimationFrame(tick);
  }
  tick();

  Promise.all([
    new Promise(r => window.addEventListener('load', r, { once: true })),
    new Promise(r => setTimeout(r, MIN_DURATION)),
    document.fonts?.ready ?? Promise.resolve(),
  ]).then(() => {
    if (pct) pct.textContent = '100%';
    document.body.classList.add('is-loaded');
    el.classList.add('is-done');
    setTimeout(() => el.remove(), 800);
    runHeroEntrance();
  });
}

function initLenis() {
  lenis = new Lenis({
    duration: 1.1,
    easing: t => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
    smoothWheel: true,
  });
  lenis.on('scroll', ScrollTrigger.update);
  gsap.ticker.add(time => lenis.raf(time * 1000));
  gsap.ticker.lagSmoothing(0);
  window.lenis = lenis;
}

function runHeroEntrance() {
  const tl = gsap.timeline({ defaults: { ease: 'power3.out' } });
  tl.fromTo('[data-hero-headline] .char-line', { y: '110%' }, { y: '0%', duration: 1.2, stagger: 0.15 }, 0);
  tl.fromTo('[data-hero-headline] .rotating-word', { opacity: 0, y: 30 }, { opacity: 1, y: 0, duration: 0.9 }, 0.4);
  tl.fromTo('[data-hero-fade]', { opacity: 0, y: 30 }, { opacity: 1, y: 0, duration: 0.9, stagger: 0.12 }, 0.2);
  tl.fromTo('[data-hero-visual] .hero-visual', { opacity: 0, scale: 0.95, y: 40 },
    { opacity: 1, scale: 1, y: 0, duration: 1.2, ease: 'power4.out' }, 0.1);
  tl.fromTo('[data-hero-tag]', { opacity: 0, scale: 0.6, y: 20 },
    { opacity: 1, scale: 1, y: 0, duration: 0.7, stagger: 0.15, ease: 'back.out(1.6)' }, 0.9);
}

function initRotator() {
  const root = document.getElementById('rotWord');
  if (!root) return;
  const items = [...root.querySelectorAll('.rw-item')];
  if (items.length < 2) return;

  const imgLayers = [...document.querySelectorAll('.hero-image-layer')];
  const imgLabels = [...document.querySelectorAll('.hero-layer-label')];

  let idx = 0;
  setInterval(() => {
    const cur = items[idx];
    idx = (idx + 1) % items.length;
    const next = items[idx];
    cur.classList.add('is-exit'); cur.classList.remove('is-active');
    requestAnimationFrame(() => next.classList.add('is-active'));
    setTimeout(() => cur.classList.remove('is-exit'), 700);
    imgLayers.forEach((l, i) => l.classList.toggle('is-active', i === idx));
    imgLabels.forEach((l, i) => l.classList.toggle('is-active', i === idx));
  }, 3200);
}

function initReveals() {
  gsap.utils.toArray('[data-reveal]').forEach(el => {
    gsap.fromTo(el, { opacity: 0, y: 40 },
      { opacity: 1, y: 0, duration: 1, ease: 'power3.out',
        scrollTrigger: { trigger: el, start: 'top 88%' } });
  });
  gsap.utils.toArray('[data-stagger]').forEach(c => {
    gsap.fromTo(c.children, { opacity: 0, y: 40 },
      { opacity: 1, y: 0, duration: 0.8, ease: 'power3.out', stagger: 0.08,
        scrollTrigger: { trigger: c, start: 'top 85%' } });
  });
}

function initCounters() {
  gsap.utils.toArray('[data-counter]').forEach(el => {
    const target = parseFloat(el.getAttribute('data-target'));
    const obj = { n: 0 };
    ScrollTrigger.create({
      trigger: el, start: 'top 92%', once: true,
      onEnter: () => gsap.to(obj, { n: target, duration: 2, ease: 'power3.out',
        onUpdate: () => el.textContent = Math.round(obj.n).toLocaleString('en-US') }),
    });
  });
}

function initMagnetic() {
  document.querySelectorAll('[data-magnetic]').forEach(btn => {
    btn.addEventListener('mousemove', e => {
      const r = btn.getBoundingClientRect();
      const x = e.clientX - r.left - r.width / 2;
      const y = e.clientY - r.top - r.height / 2;
      btn.style.transform = `translate(${x * 0.15}px, ${y * 0.25}px)`;
    });
    btn.addEventListener('mouseleave', () => { btn.style.transform = ''; });
  });
}

function initFaq() {
  document.querySelectorAll('.faq-item').forEach(item => {
    item.querySelector('.faq-q')?.addEventListener('click', () => {
      const open = item.classList.toggle('is-open');
      item.querySelector('.faq-q').setAttribute('aria-expanded', String(open));
      lenis?.resize();
    });
  });
}

function initMobileMenu() {
  const btn = document.getElementById('mobBtn');
  const drawer = document.getElementById('mobDrawer');
  if (!btn || !drawer) return;
  const set = open => {
    drawer.classList.toggle('is-open', open);
    open ? lenis?.stop() : lenis?.start();
  };
  btn.addEventListener('click', () => set(!drawer.classList.contains('is-open')));
  document.querySelectorAll('[data-mob-link]').forEach(l => l.addEventListener('click', () => set(false)));
}

function initStagesSlider() {
  const track = document.getElementById('stagesTrack');
  const prev = document.getElementById('stagesPrev');
  const next = document.getElementById('stagesNext');
  if (!track || !prev || !next) return;
  const step = () => (track.querySelector('.stage-card')?.offsetWidth || 380) + 20;
  prev.addEventListener('click', () => track.scrollBy({ left: step(), behavior: 'smooth' }));
  next.addEventListener('click', () => track.scrollBy({ left: -step(), behavior: 'smooth' }));
}

function initProjectsFilter() {
  const pills = document.querySelectorAll('#projectFilters .filter-pill');
  const tiles = document.querySelectorAll('#projectsGrid .project-tile');
  pills.forEach(p => p.addEventListener('click', () => {
    pills.forEach(b => b.classList.remove('is-active'));
    p.classList.add('is-active');
    const cat = p.getAttribute('data-filter');
    tiles.forEach(t => {
      const show = cat === 'all' || t.getAttribute('data-cat') === cat;
      gsap.to(t, {
        opacity: show ? 1 : 0, scale: show ? 1 : 0.92, duration: 0.4,
        onStart: () => { if (show) t.style.display = ''; },
        onComplete: () => { t.style.display = show ? '' : 'none'; },
      });
    });
  }));
}

function initSmoothAnchors() {
  document.querySelectorAll('a[href^="#"]').forEach(a => {
    a.addEventListener('click', e => {
      const target = document.querySelector(a.getAttribute('href'));
      if (target) { e.preventDefault(); lenis?.scrollTo(target, { offset: -76, duration: 1.4 }); }
    });
  });
}
